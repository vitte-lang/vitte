# Vitte fuzz (max)

Objectif: fuzzing du compilateur `vittec` (C) + parsers auxiliaires (.muf, json, etc.).

Cibles couvertes:
- Lexer: robustesse UTF-8, commentaires, strings, `.end`
- Parser (stub ou complet): tolérance erreurs + pas de crash
- Émetteur C: pas de crash sur AST/IR bizarres (quand dispo)
- Parser Muffin (.muf): parse + erreurs sans crash
- (Optionnel) stdlib parsers: json/toml/yaml/csv

Engines:
- libFuzzer (clang): recommandé
- AFL++ (clang/gcc): en parallèle
- honggfuzz: optionnel

Sanitizers:
- ASan + UBSan (default)
- MSan (si toolchain support)
- TSan (pour composants thread)

Note:
- Tous les scripts supposent un compilateur clang récent.
