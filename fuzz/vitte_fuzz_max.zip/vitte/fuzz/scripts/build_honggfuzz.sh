#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
OUT="$ROOT/out/honggfuzz"
mkdir -p "$OUT"

COMPILER_DIR="${COMPILER_DIR:-$ROOT/../compiler}"
INC="-I$COMPILER_DIR/include -I$ROOT/targets/honggfuzz"
CC="${CC:-clang}"
CFLAGS="${CFLAGS:--std=c11 -O1 -g -fno-omit-frame-pointer}"
SAN="${SAN:--fsanitize=address,undefined}"

SRCS="
$COMPILER_DIR/src/support/assert.c
$COMPILER_DIR/src/support/arena.c
$COMPILER_DIR/src/support/str.c
$COMPILER_DIR/src/support/vec.c
$COMPILER_DIR/src/support/fs.c
$COMPILER_DIR/src/support/log.c
$COMPILER_DIR/src/diag/source_map.c
$COMPILER_DIR/src/diag/diagnostic.c
$COMPILER_DIR/src/front/lexer.c
$COMPILER_DIR/src/front/parser.c
$COMPILER_DIR/src/back/emit_c.c
$COMPILER_DIR/src/vittec.c
"

"$CC" $CFLAGS $SAN $INC "$ROOT/targets/honggfuzz/hfuzz_lexer.c" $SRCS -o "$OUT/hfuzz_lexer"
echo "built honggfuzz target in: $OUT"
