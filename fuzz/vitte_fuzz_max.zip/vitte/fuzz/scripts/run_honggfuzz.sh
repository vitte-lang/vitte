#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
BIN="$ROOT/out/honggfuzz/hfuzz_lexer"
CORP="$ROOT/corpora/vitte"

if [ ! -x "$BIN" ]; then
  "$ROOT/scripts/build_honggfuzz.sh"
fi

honggfuzz -i "$CORP" -- "$BIN" ___FILE___
