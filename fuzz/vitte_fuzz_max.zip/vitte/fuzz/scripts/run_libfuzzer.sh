#!/usr/bin/env sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
BIN_DIR="$ROOT/out/libfuzzer"
CORP="$ROOT/corpora/vitte"
DICT="$ROOT/dictionaries/vitte.dict"

if [ ! -x "$BIN_DIR/fuzz_lexer" ]; then
  "$ROOT/scripts/build_libfuzzer.sh"
fi

# Common knobs
export UBSAN_OPTIONS="${UBSAN_OPTIONS:-halt_on_error=1:abort_on_error=1}"
export ASAN_OPTIONS="${ASAN_OPTIONS:-abort_on_error=1:detect_leaks=1}"
JOBS="${JOBS:-4}"
TIMEOUT="${TIMEOUT:-10}"

"$BIN_DIR/fuzz_lexer" -dict="$DICT" -jobs="$JOBS" -workers="$JOBS" -timeout="$TIMEOUT" "$CORP"
"$BIN_DIR/fuzz_parser" -dict="$DICT" -jobs="$JOBS" -workers="$JOBS" -timeout="$TIMEOUT" "$CORP"
"$BIN_DIR/fuzz_emit_c" -dict="$DICT" -jobs="$JOBS" -workers="$JOBS" -timeout="$TIMEOUT" "$CORP"
