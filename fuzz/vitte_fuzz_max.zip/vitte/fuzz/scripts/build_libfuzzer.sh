#!/usr/bin/env sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
OUT="$ROOT/out/libfuzzer"
mkdir -p "$OUT"

# You can point this to your generated compiler folder.
# Default assumes: ../compiler (relative to vitte/fuzz)
COMPILER_DIR="${COMPILER_DIR:-$ROOT/../compiler}"
INC="-I$COMPILER_DIR/include -I$ROOT/targets/libfuzzer"

CC="${CC:-clang}"
CFLAGS="${CFLAGS:--std=c11 -O1 -g -fno-omit-frame-pointer}"
SAN="${SAN:--fsanitize=address,undefined}"
FUZZ="${FUZZ:--fsanitize=fuzzer}"

# Collect minimal sources from compiler (lexer + parser + diag + support).
# Adjust when your compiler grows.
SRCS="
$COMPILER_DIR/src/support/assert.c
$COMPILER_DIR/src/support/arena.c
$COMPILER_DIR/src/support/str.c
$COMPILER_DIR/src/support/vec.c
$COMPILER_DIR/src/support/fs.c
$COMPILER_DIR/src/support/log.c
$COMPILER_DIR/src/diag/source_map.c
$COMPILER_DIR/src/diag/diagnostic.c
$COMPILER_DIR/src/diag/emitter_human.c
$COMPILER_DIR/src/diag/emitter_json.c
$COMPILER_DIR/src/front/lexer.c
$COMPILER_DIR/src/front/parser.c
$COMPILER_DIR/src/back/emit_c.c
$COMPILER_DIR/src/vittec.c
"

# Targets
"$CC" $CFLAGS $SAN $FUZZ $INC \
  "$ROOT/targets/libfuzzer/fuzz_lexer.c" \
  $SRCS \
  -o "$OUT/fuzz_lexer"

"$CC" $CFLAGS $SAN $FUZZ $INC \
  "$ROOT/targets/libfuzzer/fuzz_parser.c" \
  $SRCS \
  -o "$OUT/fuzz_parser"

"$CC" $CFLAGS $SAN $FUZZ $INC \
  "$ROOT/targets/libfuzzer/fuzz_emit_c.c" \
  $SRCS \
  -o "$OUT/fuzz_emit_c"

echo "built libFuzzer targets in: $OUT"
