#!/usr/bin/env sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
OUT="$ROOT/out/aflpp"
mkdir -p "$OUT"

COMPILER_DIR="${COMPILER_DIR:-$ROOT/../compiler}"
INC="-I$COMPILER_DIR/include -I$ROOT/targets/aflpp"
CC="${CC:-afl-clang-fast}"
CFLAGS="${CFLAGS:--std=c11 -O2 -g}"

SRCS="
$COMPILER_DIR/src/support/assert.c
$COMPILER_DIR/src/support/arena.c
$COMPILER_DIR/src/support/str.c
$COMPILER_DIR/src/support/vec.c
$COMPILER_DIR/src/support/fs.c
$COMPILER_DIR/src/support/log.c
$COMPILER_DIR/src/diag/source_map.c
$COMPILER_DIR/src/diag/diagnostic.c
$COMPILER_DIR/src/front/lexer.c
$COMPILER_DIR/src/front/parser.c
$COMPILER_DIR/src/back/emit_c.c
$COMPILER_DIR/src/vittec.c
"

"$CC" $CFLAGS $INC "$ROOT/targets/aflpp/afl_harness_lexer.c" $SRCS -o "$OUT/afl_lexer"
"$CC" $CFLAGS $INC "$ROOT/targets/aflpp/afl_harness_parser.c" $SRCS -o "$OUT/afl_parser"

echo "built AFL++ targets in: $OUT"
