#!/usr/bin/env sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
BIN_DIR="$ROOT/out/aflpp"
IN="$ROOT/corpora/vitte"
OUT="$ROOT/out/aflpp_runs"

if [ ! -x "$BIN_DIR/afl_lexer" ]; then
  "$ROOT/scripts/build_aflpp.sh"
fi

mkdir -p "$OUT"
# Example (adjust AFL_PATH/CPU binding)
afl-fuzz -i "$IN" -o "$OUT/lexer" -- "$BIN_DIR/afl_lexer" @@
