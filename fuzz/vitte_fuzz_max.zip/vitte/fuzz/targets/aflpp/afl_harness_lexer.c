#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "vittec/support/fs.h"
#include "vittec/diag/source_map.h"
#include "vittec/diag/diagnostic.h"
#include "vittec/front/lexer.h"

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  vittec_file_buf_t fb;
  if (vittec_read_entire_file(argv[1], &fb) != 0) return 1;

  vittec_source_map_t sm;
  vittec_sourcemap_init(&sm);

  vittec_diag_sink_t diags;
  vittec_diag_sink_init(&diags);

  uint32_t file_id = vittec_sourcemap_add(&sm, "<afl>", fb.data, (uint32_t)fb.len);

  vittec_lexer_t lx;
  vittec_lexer_init(&lx, fb.data, (uint32_t)fb.len, file_id, &diags);

  for (;;) {
    vittec_token_t t = vittec_lex_next(&lx);
    if (t.kind == TK_EOF) break;
  }

  vittec_diag_sink_free(&diags);
  vittec_sourcemap_free(&sm);
  vittec_free_file_buf(&fb);
  return 0;
}
