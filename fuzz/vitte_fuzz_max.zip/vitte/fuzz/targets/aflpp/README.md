AFL++ harnesses accept `@@` path.
They read file content and feed lexer/parser.
