#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>

#include "fuzz_common.h"

#include "vittec/diag/source_map.h"
#include "vittec/diag/diagnostic.h"
#include "vittec/front/parser.h"

int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size) {
  if (size > (1u << 20)) return 0;

  char* src = fuzz_copy_cstr(data, size);
  if (!src) return 0;

  vittec_source_map_t sm;
  vittec_sourcemap_init(&sm);

  vittec_diag_sink_t diags;
  vittec_diag_sink_init(&diags);

  uint32_t file_id = vittec_sourcemap_add(&sm, "<fuzz>", src, (uint32_t)size);

  vittec_lexer_t lx;
  vittec_lexer_init(&lx, src, (uint32_t)size, file_id, &diags);

  vittec_parse_unit_t u;
  (void)vittec_parse_unit(&lx, &u);

  vittec_diag_sink_free(&diags);
  vittec_sourcemap_free(&sm);
  free(src);
  return 0;
}
