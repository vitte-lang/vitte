#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>

#include "fuzz_common.h"

#include "vittec/diag/source_map.h"
#include "vittec/diag/diagnostic.h"
#include "vittec/front/lexer.h"

int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size) {
  /* Avoid pathological huge inputs */
  if (size > (1u << 20)) return 0;

  char* src = fuzz_copy_cstr(data, size);
  if (!src) return 0;

  vittec_source_map_t sm;
  vittec_sourcemap_init(&sm);

  vittec_diag_sink_t diags;
  vittec_diag_sink_init(&diags);

  uint32_t file_id = vittec_sourcemap_add(&sm, "<fuzz>", src, (uint32_t)size);

  vittec_lexer_t lx;
  vittec_lexer_init(&lx, src, (uint32_t)size, file_id, &diags);

  for (;;) {
    vittec_token_t t = vittec_lex_next(&lx);
    if (t.kind == TK_EOF) break;
    /* extra: touch fields */
    (void)t.span.lo; (void)t.span.hi; (void)t.text.len;
  }

  vittec_diag_sink_free(&diags);
  vittec_sourcemap_free(&sm);
  free(src);
  return 0;
}
