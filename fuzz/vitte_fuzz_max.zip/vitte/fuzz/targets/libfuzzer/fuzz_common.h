#pragma once
#include <stdint.h>
#include <stddef.h>

/* Small helper to make an owned NUL-terminated buffer from fuzz input. */
static inline char* fuzz_copy_cstr(const uint8_t* data, size_t size) {
  char* p = (char*)malloc(size + 1);
  if (!p) return NULL;
  for (size_t i = 0; i < size; i++) p[i] = (char)data[i];
  p[size] = 0;
  return p;
}
