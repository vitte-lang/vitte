#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

#include "vittec/diag/source_map.h"
#include "vittec/diag/diagnostic.h"
#include "vittec/front/lexer.h"

/* honggfuzz provides __AFL/___FILE___ style; our runner passes file path. */
int main(int argc, char** argv) {
  if (argc != 2) return 2;
  const char* path = argv[1];

  FILE* f = fopen(path, "rb");
  if (!f) return 1;
  fseek(f, 0, SEEK_END);
  long sz = ftell(f);
  fseek(f, 0, SEEK_SET);
  if (sz < 0) { fclose(f); return 1; }

  char* buf = (char*)malloc((size_t)sz + 1);
  if (!buf) { fclose(f); return 1; }
  size_t got = fread(buf, 1, (size_t)sz, f);
  fclose(f);
  if (got != (size_t)sz) { free(buf); return 1; }
  buf[sz] = 0;

  vittec_source_map_t sm;
  vittec_sourcemap_init(&sm);
  vittec_diag_sink_t diags;
  vittec_diag_sink_init(&diags);

  uint32_t file_id = vittec_sourcemap_add(&sm, "<hfuzz>", buf, (uint32_t)sz);

  vittec_lexer_t lx;
  vittec_lexer_init(&lx, buf, (uint32_t)sz, file_id, &diags);
  for (;;) {
    vittec_token_t t = vittec_lex_next(&lx);
    if (t.kind == TK_EOF) break;
  }

  vittec_diag_sink_free(&diags);
  vittec_sourcemap_free(&sm);
  free(buf);
  return 0;
}
