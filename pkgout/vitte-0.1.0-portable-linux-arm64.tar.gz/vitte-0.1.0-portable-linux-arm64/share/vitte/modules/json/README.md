# Vitte JSON module

`json` is a Vitte source package laid out under the `json` namespace. Module
paths use `::`, as required by the Vitte grammar. For example:

```vitte
use json::error::position::{JsonPosition, start};

let origin: JsonPosition = start();
```

The source tree includes value, lexer, parser, encoder, and error/position
modules. The package currently has no native C ABI or native runtime files;
`runtime/numeric.vit` is Vitte source.

## Build and install

From the repository root:

```sh
make -C modules/json check
make -C modules/json test-vitte
make install PREFIX="$HOME/.local"
```

`test-vitte` stages a compiler installation, then compiles and runs a consumer
that imports the position module and calls `position::start()` from the
installed source tree.
Normal `make install` installs the compiler and JSON source tree under
`$PREFIX/share/vitte/modules/json`; `make uninstall` removes both. A staged
installation can be made with `DESTDIR`, for example:

```sh
make install PREFIX=/usr/local DESTDIR="$PWD/modules/json/build/stage"
```

An installed compiler searches the module directory beside its own `bin`
directory. Additional module roots can be provided as a colon-separated
`VITTE_MODULE_PATH`. This is useful for development or a compiler invoked via a
custom wrapper.

## Current compiler compatibility

The compiler parses and semantically checks every library source through
`make check-library`, including slice types, numeric `as` casts, keyword-named
`null()` procedures, and procedure prototypes. The C backend emits procedures
nested in imported spaces, handles reference arguments for those procedures,
and lowers `string.length` and dynamic string concatenation. `test-vitte`
verifies that an installed consumer can call `position::start()`.

`make -C modules/json test-runtime` runs the numeric runtime tests, and
`test-vitte` verifies an installed consumer of the error/position API. The
encoder integration test is still blocked in the C17 backend: unsized array
types such as `[JsonValue]` are accepted by parsing and semantic analysis, but
the C emitter only handles fixed-length array declarations. Emitting
`JsonValue.array_value` therefore stops during C generation, before the
encoder test can run. The module is not yet validated as a complete runtime
library. `check-library` checks the syntax and semantics of each source
independently; it does not guarantee that every feature can be emitted by the
native backend.

`package.toml` records package identity and layout. The compiler does not yet
consume this manifest or provide a general package manager.
