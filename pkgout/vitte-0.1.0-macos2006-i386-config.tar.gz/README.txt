Vitte 0.1.0 historical Mac OS X 2006 i386 build profile

Architecture: i386
Deployment target: Mac OS X 10.4
SDK: MacOSX10.4u.sdk
Compiler: gcc-4.0

Build binary:

    make macos2006-i386-bin

Build installer:

    ARCH=macos2006-i386 scripts/build-macos-installers.sh

The installer contains native syntax highlighting for Vim, Emacs, Nano
and Geany.
