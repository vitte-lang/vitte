;;; 50vitte.el --- system-wide Vitte mode registration

(add-to-list 'load-path "/usr/local/share/emacs/site-lisp")
(add-to-list 'load-path "/usr/share/emacs/site-lisp/vitte")

(autoload 'vitte-mode
  "vitte-mode"
  "Major mode for the Vitte programming language."
  t)

(add-to-list 'auto-mode-alist '("\\.vit\\'" . vitte-mode))
(add-to-list 'auto-mode-alist '("\\.vitte\\'" . vitte-mode))
(add-to-list 'auto-mode-alist '("\\.vitl\\'" . vitte-mode))

(provide 'vitte-system-init)

;;; 50vitte.el ends here
